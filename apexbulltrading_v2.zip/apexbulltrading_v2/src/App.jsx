import React from 'react';

export default function App() {
  return (
    <div style={{ padding: '2rem', textAlign: 'center', color: 'white', backgroundColor: '#111', height: '100vh' }}>
      <h1 style={{ color: 'lime' }}>Apexbulltrading</h1>
      <p>This na your fake investment broker website (demo only)</p>
      <p>We dey back your success 📈💰</p>
    </div>
  );
}